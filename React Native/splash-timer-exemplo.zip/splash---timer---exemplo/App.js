/* imports Padrão */
import { useState, useEffect } from 'react';

/* Screens */
import Splash from './src/screens/splash_screen';
import Inicial_screen from './src/screens/inicial_screen';


export default function App() {

  const [carregando, setCarregando] = useState(true);

  useEffect(() => {

    setTimeout(() => {
      setCarregando(false);
    }, 3000);

  }, []);

  if (carregando) {
    return (
      <Splash />
    );
  }

  return (
    <Inicial_screen />
  );
}