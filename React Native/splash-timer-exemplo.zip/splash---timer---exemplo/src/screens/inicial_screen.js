import {Text, StyleSheet, View} from 'react-native';

const Inicial_screen = () => {

  return(
    <View style={styles.container}>
      <Text style={styles.titulo}>Desenvolvimento de Aplicações Móveis</Text>
      <Text style={styles.paragrafo}>Nesta disciplina vamos aprender a desenvolver apps, tanto para os sistemas operacionais Android quanto IOS, com o React Native e a plataforma Expo Go.</Text>
    </View>
  );

}


const styles = StyleSheet.create({
  container:{
    flex: 1, // This makes the ImageBackground component fill the entire screen
    justifyContent: 'center', // Centers children vertically
    alignItems: 'center', // Centers children horizontally
  },
  titulo:{
    fontWeight: "bold",
    fontSize: 20,
    textAlign: 'center'
  },
  paragrafo:{
    fontSize: 16,
    lineHeight: 25,
    marginTop: 10
  }
});
export default Inicial_screen;