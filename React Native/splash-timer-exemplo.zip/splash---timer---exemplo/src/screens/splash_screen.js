import {View, Text, ImageBackground, StyleSheet} from 'react-native';
import { ActivityIndicator, MD2Colors } from 'react-native-paper';

const Splash_screen = () => {

 const imageSource = require('../img/brasao_pucminas.png');

  return(

    <ImageBackground
      source={imageSource}
      style={styles.background} // Apply style to the container
      // resizeMode="cover" is the default, but you can explicitly set it
      resizeMode="contain" 
    >

    <View style={styles.contentContainer} >
        <Text style={styles.text} >Desenvolvimento de Aplicações Móveis</Text>
        <ActivityIndicator animating={true} />
    </View>
    </ImageBackground>
  );

}

const styles = StyleSheet.create({
  background: {
    flex: 1, // This makes the ImageBackground component fill the entire screen
    justifyContent: 'center', // Centers children vertically
    alignItems: 'center', // Centers children horizontally
  },
  contentContainer: {
    // Styles for the view overlaying the image
    padding: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.5)', // Semi-transparent overlay for readability
    borderRadius: 10,
    marginTop: 300
  },
  text: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center'
  },
});

export default Splash_screen;