import React, { useState } from 'react';
import { View, Button, StyleSheet, Alert, Text } from 'react-native';
import { Audio } from 'expo-av';

export default function AudioPlayerExample() {
  const [sound, setSound] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [loading, setLoading] = useState(false);

  // 1. Carregar, Reproduzir ou Retomar o Áudio
  async function playSound() {
    if (loading) return;
    setLoading(true);

    try {
      // Se já houver um objeto de som carregado, apenas retoma a reprodução
      if (sound) {
        await sound.playAsync(); // Usa playAsync para continuar de onde parou
        setIsPlaying(true);
        setLoading(false);
        return;
      }

      // 1.1 Configuração da Categoria de Áudio
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        playsInSilentModeIOS: true,
        shouldDuckAndroid: true,
        staysActiveInBackground: false,
        playThroughEarpieceAndroid: false,
      });

      // 1.2 Carrega o som (renomeado internamente para 'playbackObject' para evitar conflito com o estado)
      const { sound: playbackObject } = await Audio.Sound.createAsync(
        require('./assets/sounds/hungriahiphop.mp3'),
        { shouldPlay: true },
        onPlaybackStatusUpdate
      );
      
      setSound(playbackObject); // Guarda a referência correta no estado
      setIsPlaying(true);
    } catch (error) {
      console.error('Erro ao tocar o som:', error);
      Alert.alert('Erro de Áudio', 'Não foi possível reproduzir o som.');
    } finally {
      setLoading(false);
    }
  }

  // Monitora o status da reprodução
  const onPlaybackStatusUpdate = (status) => {
    if (status.didJustFinish) {
      setIsPlaying(false);
    }
  };

  // 2. Pausar a Reprodução (Mantém a posição atual do áudio)
  async function pauseSound() {
    if (sound) {
      await sound.pauseAsync();
      setIsPlaying(false);
    }
  }

  // 3. Descarregar o Áudio (Limpeza de memória ao desmontar o componente)
  React.useEffect(() => {
    return sound
      ? () => {
          console.log('Descarregando Áudio...');
          sound.unloadAsync();
        }
      : undefined;
  }, [sound]);

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Reprodução de Áudio com expo-av</Text>
      <Text style={styles.status}>Status: {isPlaying ? 'Tocando...' : 'Pausado'}</Text>
      
      <Button 
        title={isPlaying ? 'Pausar' : 'Tocar Som'} 
        onPress={isPlaying ? pauseSound : playSound}
        disabled={loading}
        color={isPlaying ? '#e74c3c' : '#2ecc71'}
      />
      
      {loading && <Text style={styles.loading}>Processando áudio...</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  titulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 30,
  },
  status: {
    fontSize: 16,
    marginBottom: 20,
  },
  loading: {
    marginTop: 10,
    color: '#888',
  }
});