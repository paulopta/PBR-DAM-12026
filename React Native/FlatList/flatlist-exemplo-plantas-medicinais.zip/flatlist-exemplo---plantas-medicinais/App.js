import Exibe_plantas from './assets/screens/exibe_plantas'

export default function App() {
  return (
    <>
      <Exibe_plantas />
    </>   
  );
}
