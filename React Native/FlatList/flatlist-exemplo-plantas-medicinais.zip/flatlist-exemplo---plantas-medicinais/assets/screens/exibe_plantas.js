import { Image, View, Text, StyleSheet, FlatList } from 'react-native';

//importação dos dados
import data from '../data/plantas.json'

const Exibe_plantas = () => {

  const renderItem = ({ item }) => (
  <View style={styles.item}>
    <Text style={styles.titulo}><Image source={{uri:item.imagem}} style={{width: 100, height: 100}} /></Text>
    <Text style={styles.titulo}>{item.nomePopular} / {item.nomeCientifico}</Text>
    <Text style={styles.descricao}>{item.uso}</Text>
  </View>
);

  return (
    <View style={styles.container}>
      <FlatList
        data={data}
        renderItem={renderItem}
        keyExtractor={item => item.id}
      />
    </View>
  );

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  item: {
    backgroundColor: '#fff',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
    borderRadius: 5,
  },
  titulo: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  descricao: {
    fontSize: 14,
    color: '#666',
  },
});

export default Exibe_plantas;